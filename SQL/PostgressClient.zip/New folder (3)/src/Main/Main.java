package Main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Main {

    public static void main(String[] args) throws IOException, SQLException {
        System.out.println("Welcome!!\n");


        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String selection;

        do{
            do{
                System.out.println("Please Select which query you want to run:\n" +
                        "(a) Πόσες κρατήσεις αντιστοιχούν σε κάθε κατηγορία δωματίων.\n" +
                        "(b) Ποια κατηγορία δωματίων παρουσιάζει βάσει των κρατήσεων τον μεγαλύτερο τζίρο.\n" +
                        "(c) Πόσα δωμάτια είναι προς το παρόν διαθέσιμα προς κράτηση.\n" +
                        "(d) Ποιες παροχές (facilities) διατίθενται σε συγκεκριμένα δωμάτια.\n" +
                        "(e) Ποιοι επισκέπτες έχουν κράτηση αυτό το μήνα.\n" +
                        "(f) Ποιο είναι το μέσο κέρδος ανά τύπο/κατηγορία δωματίου για τη θερινή σεζόν.\n" +
                        "(g) Ποιος είναι ο πελάτης με τις περισσότερες κρατήσεις ανά εύρος ζώνης τιμής δωματίου.\n" +
                        "(h) Ποια δωμάτια ενοικιάστηκαν από την ημερομηνία “X” έως και σήμερα.\n" +
                        "OR WRITE 0 (NUMBER) TO EXIT!\n");
                selection = reader.readLine();
            }while (!(selection.equals("a") || selection.equals("b") || selection.equals("c") || selection.equals("d") || selection.equals("e") || selection.equals("f") || selection.equals("g") || selection.equals("h")|| selection.equals("0")));
            Connection myConn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/courses", "postgres", "1234");
            Statement myStmt = myConn.createStatement();
            switch (selection) {
                case "a": {
                    String query = "SELECT ROOMFULLNAME,COUNT(ROOMFULLNAME) AS NUM\n" +
                            "FROM RESERVATIONS,ROOMS\n" +
                            "WHERE RESERVATIONS.ROOMID = ROOMS.ROOMID\n" +
                            "GROUP BY ROOMFULLNAME;";
                    ResultSet rs = myStmt.executeQuery(query);

                    System.out.println("ROOMFULLNAME" + "   ||   " + "NUM");
                    System.out.println("==============================");

                    while (rs.next()) {

                        System.out.println(rs.getString("ROOMFULLNAME") + "   ||   " + rs.getString("NUM") + "\n");
                    }
                    break;
                }
                case "b": {

                    String query = "DROP TABLE IF EXISTS TURNOVERS; -- TEMP TABLE WITH ALL TURNOVERS (TZIROI)\n" +
                            "CREATE TEMPORARY TABLE TURNOVERS AS(SELECT ROOMFULLNAME,SUM(BILL) AS TURNOVER\n" +
                            "FROM RESERVATIONS,RESERVATION_PAYMENT,ROOMS\n" +
                            "WHERE RESERVATIONS.RESERVATIONID = RESERVATION_PAYMENT.RESERVATIONID AND RESERVATIONS.ROOMID = ROOMS.ROOMID \n" +
                            "GROUP BY ROOMFULLNAME);";
                    String query1 = "WITH MAX_ AS (SELECT MAX(TURNOVER) AS MAX_T FROM TURNOVERS )\n" +
                            "SELECT * FROM TURNOVERS WHERE TURNOVER=(SELECT MAX_T FROM MAX_);";
                    myStmt.execute(query);
                    ResultSet rs = myStmt.executeQuery(query1);

                    System.out.println("ROOMFULLNAME" + "   ||   " + "TURNOVER");
                    System.out.println("==============================");

                    while (rs.next()) {

                        System.out.println(rs.getString("ROOMFULLNAME") + "   ||   " + rs.getString("TURNOVER")  + "\n");
                    }
                    break;
                }
                case "c": {

                    String query = "WITH ENGAGED AS(SELECT ROOMID FROM RESERVATIONS WHERE CHECK_IN <= CURRENT_DATE AND CHECK_OUT > CURRENT_DATE)\n" +
                            "\n" +
                            "SELECT 'AVAILABLE ROOMS',COUNT(*) FROM ROOMS,ENGAGED WHERE ROOMS.ROOMID != ENGAGED.ROOMID;";
                    ResultSet rs = myStmt.executeQuery(query);

                    while (rs.next()) {

                        System.out.println("AVAILABLE ROOMS   ||   " + rs.getString("count")  + "\n");
                        System.out.println("==============================");
                    }
                    break;
                }
                case "d": {
                    String query = "SELECT ROOMS.ROOMID,ROOMFULLNAME,ROOM_FACILITIES.BreakFast, ROOM_FACILITIES.StreetView, ROOM_FACILITIES.SeaView, ROOM_FACILITIES.MountainView, ROOM_FACILITIES.Spa, ROOM_FACILITIES.Bathtub, ROOM_FACILITIES.Shower, ROOM_FACILITIES.TV\n" +
                            "FROM ROOMS,ROOM_FACILITIES\n" +
                            "WHERE ROOMS.ROOMID = ROOM_FACILITIES.ROOMID;";
                    ResultSet rs = myStmt.executeQuery(query);

                    System.out.println("ROOMID" + "   ||   " + "ROOMFULLNAME" + "   ||   " + "BREAKFAST" + "   ||   " + "STREET VIEW" + "   ||   " + "SEA VIEW" + "   ||   " + "MOUNTAIN VIEW" + "   ||   " + "SPA" + "   ||   " + "BATHTUB" + "   ||   " + "SHOWER" + "   ||   " + "TV");
                    System.out.println("=============================================================================================================================================================================================================");

                    while (rs.next()) {

                        System.out.println(rs.getString("ROOMID") + "   ||   " + rs.getString("ROOMFULLNAME") + "   ||   " + rs.getString("BREAKFAST") + "   ||   " + rs.getString("STREETVIEW") + "   ||   " + rs.getString("SEAVIEW") + "   ||   " + rs.getString("MOUNTAINVIEW") + "   ||   " + rs.getString("SPA") + "   ||   " + rs.getString("BATHTUB") + "   ||   " + rs.getString("SHOWER") + "   ||   " + rs.getString("TV")  + "\n");
                    }
                    break;
                }
                case "e": {
                    String query = "SELECT RESERVATIONID,NAMEOFRESERVATION,CHECK_IN,CHECK_OUT,ROOMID\n" +
                            "FROM RESERVATIONS\n" +
                            "WHERE ((EXTRACT(MONTH FROM CHECK_IN) = EXTRACT(MONTH FROM LOCALTIMESTAMP) )OR (EXTRACT(MONTH FROM CHECK_OUT) = EXTRACT(MONTH FROM LOCALTIMESTAMP)) )\n" +
                            "\t\tAND ((EXTRACT(YEAR FROM CHECK_IN) = EXTRACT(YEAR FROM LOCALTIMESTAMP)) OR (EXTRACT(YEAR FROM CHECK_OUT) = EXTRACT(YEAR FROM LOCALTIMESTAMP)));";
                    ResultSet rs = myStmt.executeQuery(query);

                    System.out.println("RESERVATIONID" + "   ||   " + "NAME OF RESERVATION" + "   ||   " + "CHECK IN" + "   ||   " + "CHECK OUT" + "   ||   " + "ROOMID");
                    System.out.println("==============================================================================================");

                    while (rs.next()) {

                        System.out.println(rs.getString("RESERVATIONID") + "   ||   " + rs.getString("NAMEOFRESERVATION") + "   ||   " + rs.getString("CHECK_IN") + "   ||   " + rs.getString("CHECK_OUT") + "   ||   " + rs.getString("ROOMID")  + "\n");
                    }
                    break;
                }
                case "f": {
                    String query = "SELECT ROOMFULLNAME,ROUND(AVG(BILL),2)\n" +
                            "FROM RESERVATIONS,RESERVATION_PAYMENT,ROOMS\n" +
                            "WHERE RESERVATIONS.PAYMENTID = RESERVATION_PAYMENT.PAYMENTID AND (EXTRACT(MONTH FROM CHECK_IN) >= 6) AND (EXTRACT(MONTH FROM CHECK_IN)<=9) AND RESERVATIONS.ROOMID = ROOMS.ROOMID \n" +
                            "AND (EXTRACT(YEAR FROM CHECK_IN) = EXTRACT(YEAR FROM LOCALTIMESTAMP))\n" +
                            "GROUP BY RESERVATIONS.ROOMID,ROOMFULLNAME";
                    ResultSet rs = myStmt.executeQuery(query);

                    System.out.println("ROOMFULLNAME" + "   ||   " + "BILL PER ROOM");
                    System.out.println("========================================");

                    while (rs.next()) {

                        System.out.println(rs.getString("ROOMFULLNAME") + "   ||   " + rs.getString("ROUND")  + "\n");
                    }
                    break;
                }
                case "g": {
                    String query = "WITH SDA AS(\n" +
                            "SELECT NAMEOFRESERVATION,ROOMFULLNAME,SUM(NUMBEROFROOMS) AS SUMA\n" +
                            "FROM RESERVATIONS,ROOMS\n" +
                            "WHERE RESERVATIONS.ROOMID = ROOMS.ROOMID\n" +
                            "GROUP BY ROOMFULLNAME,nameofreservation\n" +
                            "ORDER BY ROOMFULLNAME)\n" +
                            ",\n" +
                            "MAX_SDA AS (\n" +
                            "SELECT ROOMFULLNAME,MAX(SUMA) AS MAX_SUMA\n" +
                            "FROM SDA\n" +
                            "GROUP BY ROOMFULLNAME)\n" +
                            "\n" +
                            "SELECT NAMEOFRESERVATION,MAX_SDA.ROOMFULLNAME,MAX_SUMA\n" +
                            "FROM SDA,MAX_SDA\n" +
                            "WHERE SUMA = MAX_SUMA AND MAX_SDA.ROOMFULLNAME = SDA.ROOMFULLNAME;";
                    ResultSet rs = myStmt.executeQuery(query);

                    System.out.println("NAME OF RESERVATION" + "   ||   " + "ROOMFULLNAME" + "   ||   " + "MAX_SUMA");
                    System.out.println("========================================");

                    while (rs.next()) {

                        System.out.println(rs.getString("NAMEOFRESERVATION") + "   ||   " + rs.getString("ROOMFULLNAME") + "   ||   " + rs.getString("MAX_SUMA")  + "\n");
                    }
                    break;
                }
                case "h": {
                    String query = "SELECT NAMEOFRESERVATION,RESERVATIONS.ROOMID,ROOMFULLNAME,CHECK_IN,CHECK_OUT\n" +
                            "FROM RESERVATIONS,ROOMS\n" +
                            "WHERE CHECK_IN >= '2020-01-01'::DATE AND CHECK_IN <= CURRENT_DATE AND RESERVATIONS.ROOMID = ROOMS.ROOMID\n" +
                            "ORDER BY CHECK_IN;";
                    ResultSet rs = myStmt.executeQuery(query);

                    System.out.println("NAME OF RESERVATION" + "   ||   " + "ROOMID" + "   ||   " + "ROOMFULLNAME" + "   ||   " + "   ||   " + "CHECK IN" + "   ||   " + "CHECK OUT");
                    System.out.println("===========================================================================================");

                    while (rs.next()) {

                        System.out.println(rs.getString("NAMEOFRESERVATION") + "   ||   " + rs.getString("ROOMID") + "   ||   " + rs.getString("ROOMFULLNAME") + "   ||   " + rs.getString("CHECK_IN") + "   ||   " + rs.getString("CHECK_OUT")  + "\n");
                    }
                    break;
                }
            }
        }while (!selection.equals("0"));
    }
}

